﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Staffmanagement
{
    public partial class Dashboard : Form
    {
        public Dashboard()
        {
            InitializeComponent();
        }

        private void Dashboard_Load(object sender, EventArgs e)
        {
            
        }

        private void staffdetailsToolStripMenuItem_Click(object sender, EventArgs e)
        {
            
        }

        private void staffReportsToolStripMenuItem_Click(object sender, EventArgs e)
        {
            StaffReports obj = new StaffReports();
            obj.Show();
            this.Hide();                            
            

        }

        private void benefitReportToolStripMenuItem_Click(object sender, EventArgs e)
        {

        }
    }
}
