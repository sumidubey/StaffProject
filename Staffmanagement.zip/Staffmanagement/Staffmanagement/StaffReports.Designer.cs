﻿namespace Staffmanagement
{
    partial class StaffReports
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.lblname = new System.Windows.Forms.Label();
            this.lbldes = new System.Windows.Forms.Label();
            this.lblemail = new System.Windows.Forms.Label();
            this.lblcontact = new System.Windows.Forms.Label();
            this.lbldob = new System.Windows.Forms.Label();
            this.lblgen = new System.Windows.Forms.Label();
            this.lbladd = new System.Windows.Forms.Label();
            this.txtname = new System.Windows.Forms.TextBox();
            this.cbdes = new System.Windows.Forms.ComboBox();
            this.txtmail = new System.Windows.Forms.TextBox();
            this.txtcon = new System.Windows.Forms.TextBox();
            this.dtdob = new System.Windows.Forms.DateTimePicker();
            this.cbgen = new System.Windows.Forms.ComboBox();
            this.txtadd = new System.Windows.Forms.TextBox();
            this.btnadd = new System.Windows.Forms.Button();
            this.btnupdate = new System.Windows.Forms.Button();
            this.btndelete = new System.Windows.Forms.Button();
            this.btnbtm = new System.Windows.Forms.Button();
            this.btnclear = new System.Windows.Forms.Button();
            this.StaffDGV = new System.Windows.Forms.DataGridView();
            ((System.ComponentModel.ISupportInitialize)(this.StaffDGV)).BeginInit();
            this.SuspendLayout();
            // 
            // lblname
            // 
            this.lblname.AutoSize = true;
            this.lblname.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblname.Location = new System.Drawing.Point(43, 32);
            this.lblname.Name = "lblname";
            this.lblname.Size = new System.Drawing.Size(47, 16);
            this.lblname.TabIndex = 0;
            this.lblname.Text = "NAME";
            // 
            // lbldes
            // 
            this.lbldes.AutoSize = true;
            this.lbldes.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbldes.Location = new System.Drawing.Point(43, 75);
            this.lbldes.Name = "lbldes";
            this.lbldes.Size = new System.Drawing.Size(100, 16);
            this.lbldes.TabIndex = 1;
            this.lbldes.Text = "DESIGNATION";
            // 
            // lblemail
            // 
            this.lblemail.AutoSize = true;
            this.lblemail.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblemail.Location = new System.Drawing.Point(43, 121);
            this.lblemail.Name = "lblemail";
            this.lblemail.Size = new System.Drawing.Size(47, 16);
            this.lblemail.TabIndex = 2;
            this.lblemail.Text = "EMAIL";
            // 
            // lblcontact
            // 
            this.lblcontact.AutoSize = true;
            this.lblcontact.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblcontact.Location = new System.Drawing.Point(460, 132);
            this.lblcontact.Name = "lblcontact";
            this.lblcontact.Size = new System.Drawing.Size(73, 16);
            this.lblcontact.TabIndex = 3;
            this.lblcontact.Text = "CONTACT";
            // 
            // lbldob
            // 
            this.lbldob.AutoSize = true;
            this.lbldob.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbldob.Location = new System.Drawing.Point(460, 30);
            this.lbldob.Name = "lbldob";
            this.lbldob.Size = new System.Drawing.Size(37, 16);
            this.lbldob.TabIndex = 4;
            this.lbldob.Text = "DOB";
            // 
            // lblgen
            // 
            this.lblgen.AutoSize = true;
            this.lblgen.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblgen.Location = new System.Drawing.Point(460, 75);
            this.lblgen.Name = "lblgen";
            this.lblgen.Size = new System.Drawing.Size(66, 16);
            this.lblgen.TabIndex = 5;
            this.lblgen.Text = "GENDER";
            // 
            // lbladd
            // 
            this.lbladd.AutoSize = true;
            this.lbladd.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbladd.Location = new System.Drawing.Point(43, 175);
            this.lbladd.Name = "lbladd";
            this.lbladd.Size = new System.Drawing.Size(74, 16);
            this.lbladd.TabIndex = 6;
            this.lbladd.Text = "ADDRESS";
            // 
            // txtname
            // 
            this.txtname.Location = new System.Drawing.Point(278, 32);
            this.txtname.Name = "txtname";
            this.txtname.Size = new System.Drawing.Size(147, 20);
            this.txtname.TabIndex = 7;
            // 
            // cbdes
            // 
            this.cbdes.FormattingEnabled = true;
            this.cbdes.Items.AddRange(new object[] {
            "ASSOCIATE SOFTWARE ENGINEER",
            "TEST ENGINEER",
            "SENIOUR SOFTWARE ENGINEER",
            "LEAD ARCHITECT"});
            this.cbdes.Location = new System.Drawing.Point(278, 77);
            this.cbdes.Name = "cbdes";
            this.cbdes.Size = new System.Drawing.Size(147, 21);
            this.cbdes.TabIndex = 8;
            this.cbdes.SelectedIndexChanged += new System.EventHandler(this.comboBox1_SelectedIndexChanged);
            // 
            // txtmail
            // 
            this.txtmail.Location = new System.Drawing.Point(278, 123);
            this.txtmail.Name = "txtmail";
            this.txtmail.Size = new System.Drawing.Size(147, 20);
            this.txtmail.TabIndex = 9;
            // 
            // txtcon
            // 
            this.txtcon.Location = new System.Drawing.Point(588, 131);
            this.txtcon.Name = "txtcon";
            this.txtcon.Size = new System.Drawing.Size(200, 20);
            this.txtcon.TabIndex = 10;
            this.txtcon.TextChanged += new System.EventHandler(this.textBox3_TextChanged);
            // 
            // dtdob
            // 
            this.dtdob.CustomFormat = "DD-MM-YYYY";
            this.dtdob.Format = System.Windows.Forms.DateTimePickerFormat.Custom;
            this.dtdob.Location = new System.Drawing.Point(588, 29);
            this.dtdob.Name = "dtdob";
            this.dtdob.Size = new System.Drawing.Size(200, 20);
            this.dtdob.TabIndex = 11;
            // 
            // cbgen
            // 
            this.cbgen.FormattingEnabled = true;
            this.cbgen.Items.AddRange(new object[] {
            "MALE",
            "FEMALE",
            "OTHERS"});
            this.cbgen.Location = new System.Drawing.Point(588, 77);
            this.cbgen.Name = "cbgen";
            this.cbgen.Size = new System.Drawing.Size(200, 21);
            this.cbgen.TabIndex = 12;
            // 
            // txtadd
            // 
            this.txtadd.Location = new System.Drawing.Point(278, 174);
            this.txtadd.Multiline = true;
            this.txtadd.Name = "txtadd";
            this.txtadd.Size = new System.Drawing.Size(510, 80);
            this.txtadd.TabIndex = 13;
            this.txtadd.TextChanged += new System.EventHandler(this.textBox4_TextChanged);
            // 
            // btnadd
            // 
            this.btnadd.Location = new System.Drawing.Point(78, 275);
            this.btnadd.Name = "btnadd";
            this.btnadd.Size = new System.Drawing.Size(75, 23);
            this.btnadd.TabIndex = 15;
            this.btnadd.Text = "ADD";
            this.btnadd.UseVisualStyleBackColor = true;
            this.btnadd.Click += new System.EventHandler(this.btnadd_Click);
            // 
            // btnupdate
            // 
            this.btnupdate.Location = new System.Drawing.Point(223, 275);
            this.btnupdate.Name = "btnupdate";
            this.btnupdate.Size = new System.Drawing.Size(75, 23);
            this.btnupdate.TabIndex = 16;
            this.btnupdate.Text = "UPDATE";
            this.btnupdate.UseVisualStyleBackColor = true;
            this.btnupdate.Click += new System.EventHandler(this.btnupdate_Click);
            // 
            // btndelete
            // 
            this.btndelete.Location = new System.Drawing.Point(360, 275);
            this.btndelete.Name = "btndelete";
            this.btndelete.Size = new System.Drawing.Size(75, 23);
            this.btndelete.TabIndex = 17;
            this.btndelete.Text = "DELETE";
            this.btndelete.UseVisualStyleBackColor = true;
            this.btndelete.Click += new System.EventHandler(this.btndelete_Click);
            // 
            // btnbtm
            // 
            this.btnbtm.Location = new System.Drawing.Point(510, 275);
            this.btnbtm.Name = "btnbtm";
            this.btnbtm.Size = new System.Drawing.Size(107, 23);
            this.btnbtm.TabIndex = 18;
            this.btnbtm.Text = "BACKTOMAIN";
            this.btnbtm.UseVisualStyleBackColor = true;
            this.btnbtm.Click += new System.EventHandler(this.btnbtm_Click);
            // 
            // btnclear
            // 
            this.btnclear.Location = new System.Drawing.Point(676, 275);
            this.btnclear.Name = "btnclear";
            this.btnclear.Size = new System.Drawing.Size(75, 23);
            this.btnclear.TabIndex = 19;
            this.btnclear.Text = "CLEAR";
            this.btnclear.UseVisualStyleBackColor = true;
            // 
            // StaffDGV
            // 
            this.StaffDGV.BackgroundColor = System.Drawing.Color.LavenderBlush;
            this.StaffDGV.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.StaffDGV.Location = new System.Drawing.Point(3, 352);
            this.StaffDGV.Name = "StaffDGV";
            this.StaffDGV.RowHeadersBorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.Single;
            this.StaffDGV.Size = new System.Drawing.Size(846, 150);
            this.StaffDGV.TabIndex = 20;
            this.StaffDGV.CellContentClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.StaffDGV_CellContentClick);
            // 
            // StaffReports
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.White;
            this.ClientSize = new System.Drawing.Size(923, 536);
            this.Controls.Add(this.StaffDGV);
            this.Controls.Add(this.btnclear);
            this.Controls.Add(this.btnbtm);
            this.Controls.Add(this.btndelete);
            this.Controls.Add(this.btnupdate);
            this.Controls.Add(this.btnadd);
            this.Controls.Add(this.txtadd);
            this.Controls.Add(this.cbgen);
            this.Controls.Add(this.dtdob);
            this.Controls.Add(this.txtcon);
            this.Controls.Add(this.txtmail);
            this.Controls.Add(this.cbdes);
            this.Controls.Add(this.txtname);
            this.Controls.Add(this.lbladd);
            this.Controls.Add(this.lblgen);
            this.Controls.Add(this.lbldob);
            this.Controls.Add(this.lblcontact);
            this.Controls.Add(this.lblemail);
            this.Controls.Add(this.lbldes);
            this.Controls.Add(this.lblname);
            this.Name = "StaffReports";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "StaffReports";
            this.Load += new System.EventHandler(this.StaffReports_Load);
            ((System.ComponentModel.ISupportInitialize)(this.StaffDGV)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label lblname;
        private System.Windows.Forms.Label lbldes;
        private System.Windows.Forms.Label lblemail;
        private System.Windows.Forms.Label lblcontact;
        private System.Windows.Forms.Label lbldob;
        private System.Windows.Forms.Label lblgen;
        private System.Windows.Forms.Label lbladd;
        private System.Windows.Forms.TextBox txtname;
        private System.Windows.Forms.ComboBox cbdes;
        private System.Windows.Forms.TextBox txtmail;
        private System.Windows.Forms.TextBox txtcon;
        private System.Windows.Forms.DateTimePicker dtdob;
        private System.Windows.Forms.ComboBox cbgen;
        private System.Windows.Forms.TextBox txtadd;
        private System.Windows.Forms.Button btnadd;
        private System.Windows.Forms.Button btnupdate;
        private System.Windows.Forms.Button btndelete;
        private System.Windows.Forms.Button btnbtm;
        private System.Windows.Forms.Button btnclear;
        private System.Windows.Forms.DataGridView StaffDGV;
    }
}