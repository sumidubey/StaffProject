﻿namespace Staffmanagement
{
    partial class Dashboard
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Dashboard));
            this.addstaffdetails = new System.Windows.Forms.MenuStrip();
            this.staffdetailsToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.salarymanagementToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.attendencemanagementToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.benefitsManagementToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.exitToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.staffReportsToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.salaryReportToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.attendenceReportToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.benefitReportToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.addstaffdetails.SuspendLayout();
            this.SuspendLayout();
            // 
            // addstaffdetails
            // 
            this.addstaffdetails.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.staffdetailsToolStripMenuItem,
            this.salarymanagementToolStripMenuItem,
            this.attendencemanagementToolStripMenuItem,
            this.benefitsManagementToolStripMenuItem,
            this.exitToolStripMenuItem});
            this.addstaffdetails.Location = new System.Drawing.Point(0, 0);
            this.addstaffdetails.Name = "addstaffdetails";
            this.addstaffdetails.Size = new System.Drawing.Size(800, 29);
            this.addstaffdetails.TabIndex = 0;
            this.addstaffdetails.Text = "Staff management";
            // 
            // staffdetailsToolStripMenuItem
            // 
            this.staffdetailsToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.staffReportsToolStripMenuItem});
            this.staffdetailsToolStripMenuItem.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.staffdetailsToolStripMenuItem.Name = "staffdetailsToolStripMenuItem";
            this.staffdetailsToolStripMenuItem.Size = new System.Drawing.Size(98, 25);
            this.staffdetailsToolStripMenuItem.Text = "Staffdetails";
            this.staffdetailsToolStripMenuItem.Click += new System.EventHandler(this.staffdetailsToolStripMenuItem_Click);
            // 
            // salarymanagementToolStripMenuItem
            // 
            this.salarymanagementToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.salaryReportToolStripMenuItem});
            this.salarymanagementToolStripMenuItem.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.salarymanagementToolStripMenuItem.Name = "salarymanagementToolStripMenuItem";
            this.salarymanagementToolStripMenuItem.Size = new System.Drawing.Size(155, 25);
            this.salarymanagementToolStripMenuItem.Text = "salaryManagement";
            // 
            // attendencemanagementToolStripMenuItem
            // 
            this.attendencemanagementToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.attendenceReportToolStripMenuItem});
            this.attendencemanagementToolStripMenuItem.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.attendencemanagementToolStripMenuItem.Name = "attendencemanagementToolStripMenuItem";
            this.attendencemanagementToolStripMenuItem.Size = new System.Drawing.Size(192, 25);
            this.attendencemanagementToolStripMenuItem.Text = "AttendenceManagement";
            // 
            // benefitsManagementToolStripMenuItem
            // 
            this.benefitsManagementToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.benefitReportToolStripMenuItem});
            this.benefitsManagementToolStripMenuItem.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.benefitsManagementToolStripMenuItem.Name = "benefitsManagementToolStripMenuItem";
            this.benefitsManagementToolStripMenuItem.Size = new System.Drawing.Size(162, 25);
            this.benefitsManagementToolStripMenuItem.Text = "Benefitmanagement";
            // 
            // exitToolStripMenuItem
            // 
            this.exitToolStripMenuItem.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.exitToolStripMenuItem.Name = "exitToolStripMenuItem";
            this.exitToolStripMenuItem.Size = new System.Drawing.Size(46, 25);
            this.exitToolStripMenuItem.Text = "Exit";
            // 
            // staffReportsToolStripMenuItem
            // 
            this.staffReportsToolStripMenuItem.Name = "staffReportsToolStripMenuItem";
            this.staffReportsToolStripMenuItem.Size = new System.Drawing.Size(180, 26);
            this.staffReportsToolStripMenuItem.Text = "StaffReports";
            this.staffReportsToolStripMenuItem.Click += new System.EventHandler(this.staffReportsToolStripMenuItem_Click);
            // 
            // salaryReportToolStripMenuItem
            // 
            this.salaryReportToolStripMenuItem.Name = "salaryReportToolStripMenuItem";
            this.salaryReportToolStripMenuItem.Size = new System.Drawing.Size(180, 26);
            this.salaryReportToolStripMenuItem.Text = "SalaryReport";
            // 
            // attendenceReportToolStripMenuItem
            // 
            this.attendenceReportToolStripMenuItem.Name = "attendenceReportToolStripMenuItem";
            this.attendenceReportToolStripMenuItem.Size = new System.Drawing.Size(205, 26);
            this.attendenceReportToolStripMenuItem.Text = "AttendenceReport";
            // 
            // benefitReportToolStripMenuItem
            // 
            this.benefitReportToolStripMenuItem.Name = "benefitReportToolStripMenuItem";
            this.benefitReportToolStripMenuItem.Size = new System.Drawing.Size(180, 26);
            this.benefitReportToolStripMenuItem.Text = "BenefitReport";
            this.benefitReportToolStripMenuItem.Click += new System.EventHandler(this.benefitReportToolStripMenuItem_Click);
            // 
            // Dashboard
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("$this.BackgroundImage")));
            this.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.addstaffdetails);
            this.MainMenuStrip = this.addstaffdetails;
            this.Name = "Dashboard";
            this.Text = "Dashboard";
            this.Load += new System.EventHandler(this.Dashboard_Load);
            this.addstaffdetails.ResumeLayout(false);
            this.addstaffdetails.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.MenuStrip addstaffdetails;
        private System.Windows.Forms.ToolStripMenuItem staffdetailsToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem staffReportsToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem salarymanagementToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem salaryReportToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem attendencemanagementToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem attendenceReportToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem benefitsManagementToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem benefitReportToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem exitToolStripMenuItem;
    }
}